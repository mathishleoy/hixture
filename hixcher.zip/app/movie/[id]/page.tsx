"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import Link from "next/link"
import { ArrowLeft, Eye, Heart, Plus, Check, Star, Clock, Calendar, DollarSign, Globe } from "lucide-react"
import { fetchMovieDetails, fetchMovieCredits } from "@/lib/api"
import { useUserData } from "@/lib/hooks"
import type { MovieDetails, Credits } from "@/lib/types"

export default function MoviePage({ params }: { params: { id: string } }) {
  const [movie, setMovie] = useState<MovieDetails | null>(null)
  const [credits, setCredits] = useState<Credits | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const { watched, watchlist, likes, toggleWatched, toggleWatchlist, toggleLike } = useUserData()

  const movieId = Number.parseInt(params.id, 10)
  const isWatched = watched.includes(movieId)
  const isInWatchlist = watchlist.includes(movieId)
  const isLiked = likes.includes(movieId)

  useEffect(() => {
    const loadMovieData = async () => {
      setLoading(true)
      setError(null)

      try {
        // Fetch movie details and credits in parallel
        const [movieData, creditsData] = await Promise.all([fetchMovieDetails(movieId), fetchMovieCredits(movieId)])

        setMovie(movieData)
        setCredits(creditsData)
      } catch (err) {
        console.error("Error loading movie data:", err)
        setError("Failed to load movie details. Please try again later.")
      } finally {
        setLoading(false)
      }
    }

    loadMovieData()
  }, [movieId])

  if (loading) {
    return (
      <div className="flex justify-center py-16">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-[#2383E2]"></div>
      </div>
    )
  }

  if (error || !movie) {
    return (
      <div className="space-y-6">
        <Link href="/" className="inline-flex items-center text-[#2383E2] hover:text-[#1a6fc0]">
          <ArrowLeft size={16} className="mr-2" /> Back to movies
        </Link>
        <div className="bg-red-50 text-red-600 p-4 rounded-md border border-red-200">{error || "Movie not found"}</div>
      </div>
    )
  }

  const posterUrl = movie.poster_path ? `https://image.tmdb.org/t/p/w500${movie.poster_path}` : "/placeholder.svg"
  const backdropUrl = movie.backdrop_path ? `https://image.tmdb.org/t/p/original${movie.backdrop_path}` : null
  const releaseYear = movie.release_date ? new Date(movie.release_date).getFullYear() : "N/A"

  // Get key crew members
  const director = credits?.crew.find((person) => person.job === "Director")
  const producers = credits?.crew.filter((person) => person.job === "Producer")
  const writers = credits?.crew.filter(
    (person) => person.job === "Screenplay" || person.job === "Writer" || person.job === "Story",
  )

  // Format currency
  const formatCurrency = (amount?: number) => {
    if (!amount) return "N/A"
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
      maximumFractionDigits: 0,
    }).format(amount)
  }

  return (
    <div className="space-y-8">
      <Link href="/" className="inline-flex items-center text-[#2383E2] hover:text-[#1a6fc0]">
        <ArrowLeft size={16} className="mr-2" /> Back to movies
      </Link>

      {backdropUrl && (
        <div className="relative w-full h-64 md:h-96 rounded-xl overflow-hidden shadow-sm border border-gray-200">
          <div className="absolute inset-0 bg-gradient-to-t from-white to-transparent z-10" />
          <Image
            src={backdropUrl || "/placeholder.svg"}
            alt={`${movie.title} backdrop`}
            fill
            className="object-cover"
            priority
          />
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="md:col-span-1">
          <div className="relative aspect-[2/3] rounded-lg overflow-hidden shadow-sm border border-gray-200">
            <Image src={posterUrl || "/placeholder.svg"} alt={movie.title} fill className="object-cover" priority />
          </div>

          <div className="mt-6 flex flex-col space-y-3">
            <button
              onClick={() => toggleWatched(movie.id)}
              className={`flex items-center justify-center py-2 px-4 rounded-md transition-colors ${
                isWatched
                  ? "bg-[#EBF4FF] text-[#2383E2] border border-[#BFDBFE]"
                  : "bg-white text-gray-700 border border-gray-200 hover:bg-gray-50"
              }`}
            >
              {isWatched ? <Check size={18} className="mr-2" /> : <Eye size={18} className="mr-2" />}
              {isWatched ? "Watched" : "Mark as Watched"}
            </button>

            <button
              onClick={() => toggleWatchlist(movie.id)}
              className={`flex items-center justify-center py-2 px-4 rounded-md transition-colors ${
                isInWatchlist
                  ? "bg-[#F3E8FF] text-[#9333EA] border border-[#E9D5FF]"
                  : "bg-white text-gray-700 border border-gray-200 hover:bg-gray-50"
              }`}
            >
              {isInWatchlist ? <Check size={18} className="mr-2" /> : <Plus size={18} className="mr-2" />}
              {isInWatchlist ? "In Watchlist" : "Add to Watchlist"}
            </button>

            <button
              onClick={() => toggleLike(movie.id)}
              className={`flex items-center justify-center py-2 px-4 rounded-md transition-colors ${
                isLiked
                  ? "bg-[#FEE2E2] text-[#EF4444] border border-[#FECACA]"
                  : "bg-white text-gray-700 border border-gray-200 hover:bg-gray-50"
              }`}
            >
              <Heart size={18} className={`mr-2 ${isLiked ? "fill-current" : ""}`} />
              {isLiked ? "Liked" : "Like"}
            </button>
          </div>

          {/* Movie Info */}
          <div className="mt-6 space-y-4 bg-white p-4 rounded-lg border border-gray-200">
            <h3 className="text-lg font-semibold text-gray-800">Movie Info</h3>

            <div className="space-y-3">
              <div className="flex items-start">
                <Calendar size={16} className="mr-2 mt-1 text-gray-500 flex-shrink-0" />
                <div>
                  <p className="text-sm text-gray-500">Release Date</p>
                  <p className="text-gray-800">
                    {movie.release_date ? new Date(movie.release_date).toLocaleDateString() : "N/A"}
                  </p>
                </div>
              </div>

              {movie.runtime && (
                <div className="flex items-start">
                  <Clock size={16} className="mr-2 mt-1 text-gray-500 flex-shrink-0" />
                  <div>
                    <p className="text-sm text-gray-500">Runtime</p>
                    <p className="text-gray-800">
                      {Math.floor(movie.runtime / 60)}h {movie.runtime % 60}m
                    </p>
                  </div>
                </div>
              )}

              {movie.budget !== undefined && (
                <div className="flex items-start">
                  <DollarSign size={16} className="mr-2 mt-1 text-gray-500 flex-shrink-0" />
                  <div>
                    <p className="text-sm text-gray-500">Budget</p>
                    <p className="text-gray-800">{formatCurrency(movie.budget)}</p>
                  </div>
                </div>
              )}

              {movie.revenue !== undefined && (
                <div className="flex items-start">
                  <DollarSign size={16} className="mr-2 mt-1 text-gray-500 flex-shrink-0" />
                  <div>
                    <p className="text-sm text-gray-500">Revenue</p>
                    <p className="text-gray-800">{formatCurrency(movie.revenue)}</p>
                  </div>
                </div>
              )}

              {movie.status && (
                <div className="flex items-start">
                  <Globe size={16} className="mr-2 mt-1 text-gray-500 flex-shrink-0" />
                  <div>
                    <p className="text-sm text-gray-500">Status</p>
                    <p className="text-gray-800">{movie.status}</p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="md:col-span-2 space-y-6">
          <div>
            <h1 className="text-3xl font-bold text-gray-800">{movie.title}</h1>
            {movie.title !== movie.original_title && <p className="text-gray-500 mt-1">{movie.original_title}</p>}

            {movie.tagline && <p className="text-gray-600 italic mt-2">{movie.tagline}</p>}

            <div className="flex flex-wrap items-center gap-4 mt-3 text-gray-600">
              <span>{releaseYear}</span>
              {movie.runtime && (
                <span className="flex items-center">
                  <Clock size={14} className="mr-1" />
                  {Math.floor(movie.runtime / 60)}h {movie.runtime % 60}m
                </span>
              )}
              {movie.vote_average && (
                <span className="flex items-center">
                  <Star size={14} className="mr-1 text-yellow-500" />
                  {movie.vote_average.toFixed(1)}
                </span>
              )}
            </div>
          </div>

          {movie.genres && movie.genres.length > 0 && (
            <div className="flex flex-wrap gap-2">
              {movie.genres.map((genre) => (
                <span
                  key={genre.id}
                  className="px-3 py-1 bg-gray-100 border border-gray-200 rounded-full text-sm text-gray-700"
                >
                  {genre.name}
                </span>
              ))}
            </div>
          )}

          <div className="bg-white p-4 rounded-lg border border-gray-200">
            <h2 className="text-xl font-semibold mb-3 text-gray-800">Overview</h2>
            <p className="text-gray-700 leading-relaxed">{movie.overview || "No overview available."}</p>
          </div>

          {/* Key Crew */}
          <div className="bg-white p-4 rounded-lg border border-gray-200 space-y-4">
            <h2 className="text-xl font-semibold text-gray-800">Key Crew</h2>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              {director && (
                <div>
                  <h3 className="font-medium text-gray-600">Director</h3>
                  <p className="text-gray-800">{director.name}</p>
                </div>
              )}

              {writers && writers.length > 0 && (
                <div>
                  <h3 className="font-medium text-gray-600">Writing</h3>
                  <p className="text-gray-800">{writers.map((writer) => writer.name).join(", ")}</p>
                </div>
              )}

              {producers && producers.length > 0 && (
                <div className="sm:col-span-2">
                  <h3 className="font-medium text-gray-600">Producers</h3>
                  <p className="text-gray-800">{producers.map((producer) => producer.name).join(", ")}</p>
                </div>
              )}
            </div>
          </div>

          {/* Cast */}
          {credits?.cast && credits.cast.length > 0 && (
            <div className="bg-white p-4 rounded-lg border border-gray-200 space-y-4">
              <h2 className="text-xl font-semibold text-gray-800">Cast</h2>

              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
                {credits.cast.slice(0, 8).map((person) => (
                  <div key={person.credit_id} className="bg-gray-50 rounded-lg overflow-hidden border border-gray-200">
                    <div className="relative aspect-[2/3]">
                      <Image
                        src={
                          person.profile_path
                            ? `https://image.tmdb.org/t/p/w185${person.profile_path}`
                            : "/placeholder.svg"
                        }
                        alt={person.name}
                        fill
                        className="object-cover"
                      />
                    </div>
                    <div className="p-2">
                      <p className="font-medium text-sm line-clamp-1 text-gray-800">{person.name}</p>
                      <p className="text-xs text-gray-500 line-clamp-1">{person.character}</p>
                    </div>
                  </div>
                ))}
              </div>

              {credits.cast.length > 8 && (
                <p className="text-sm text-gray-500">+{credits.cast.length - 8} more cast members</p>
              )}
            </div>
          )}

          {/* Production Companies */}
          {movie.production_companies && movie.production_companies.length > 0 && (
            <div className="bg-white p-4 rounded-lg border border-gray-200">
              <h2 className="text-xl font-semibold mb-3 text-gray-800">Production</h2>
              <div className="text-gray-700">
                {movie.production_companies.map((company) => company.name).join(", ")}
              </div>
            </div>
          )}

          {/* Production Countries */}
          {movie.production_countries && movie.production_countries.length > 0 && (
            <div className="bg-white p-4 rounded-lg border border-gray-200">
              <h2 className="text-xl font-semibold mb-3 text-gray-800">Countries</h2>
              <div className="text-gray-700">
                {movie.production_countries.map((country) => country.name).join(", ")}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
