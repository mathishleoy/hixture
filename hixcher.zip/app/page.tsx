import MovieGrid from "@/components/MovieGrid"
import SearchBar from "@/components/SearchBar"

export default function Home() {
  return (
    <div className="space-y-8">
      <SearchBar />
      <h2 className="text-2xl font-semibold">Now Playing</h2>
      <MovieGrid type="now-playing" />
    </div>
  )
}
