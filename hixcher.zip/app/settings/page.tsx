"use client"

import type React from "react"
import { useState } from "react"
import { Button } from "@/components/ui/button"

export default function SettingsPage() {
  const [importStatus, setImportStatus] = useState<string | null>(null)

  const handleExport = () => {
    // Get all user data from localStorage
    const userData = {
      watched: JSON.parse(localStorage.getItem("hixcher-watched") || "[]"),
      watchlist: JSON.parse(localStorage.getItem("hixcher-watchlist") || "[]"),
      likes: JSON.parse(localStorage.getItem("hixcher-likes") || "[]"),
    }

    // Create a Blob with the data
    const blob = new Blob([JSON.stringify(userData, null, 2)], { type: "application/json" })

    // Create a download link and trigger it
    const url = URL.createObjectURL(blob)
    const link = document.createElement("a")
    link.href = url
    link.download = "hixcher-data.json"
    document.body.appendChild(link)
    link.click()

    // Clean up
    URL.revokeObjectURL(url)
    document.body.removeChild(link)
  }

  const handleImport = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (!file) return

    const reader = new FileReader()
    reader.onload = (e) => {
      try {
        const data = JSON.parse(e.target?.result as string)

        // Validate the data structure
        if (
          data.watched &&
          Array.isArray(data.watched) &&
          data.watchlist &&
          Array.isArray(data.watchlist) &&
          data.likes &&
          Array.isArray(data.likes)
        ) {
          // Save to localStorage
          localStorage.setItem("hixcher-watched", JSON.stringify(data.watched))
          localStorage.setItem("hixcher-watchlist", JSON.stringify(data.watchlist))
          localStorage.setItem("hixcher-likes", JSON.stringify(data.likes))

          setImportStatus("Data imported successfully!")
        } else {
          setImportStatus("Invalid data format")
        }
      } catch (error) {
        setImportStatus("Error importing data")
        console.error(error)
      }
    }
    reader.readAsText(file)
  }

  return (
    <div className="max-w-md mx-auto space-y-8">
      <h2 className="text-2xl font-semibold text-gray-800">Settings</h2>

      <div className="space-y-4">
        <h3 className="text-xl text-gray-800">User Data</h3>

        <div className="space-y-4">
          <div>
            <Button onClick={handleExport} className="w-full bg-[#2383E2] hover:bg-[#1a6fc0] text-white">
              Export Data
            </Button>
            <p className="text-sm text-gray-500 mt-1">
              Download your watched, watchlist, and liked movies as a JSON file
            </p>
          </div>

          <div>
            <label className="block">
              <Button
                className="w-full bg-[#2383E2] hover:bg-[#1a6fc0] text-white"
                onClick={() => document.getElementById("file-input")?.click()}
              >
                Import Data
              </Button>
              <input id="file-input" type="file" accept=".json" className="hidden" onChange={handleImport} />
            </label>
            <p className="text-sm text-gray-500 mt-1">Import your previously exported data</p>
          </div>

          {importStatus && (
            <div
              className={`p-3 rounded border ${
                importStatus.includes("successfully")
                  ? "bg-green-50 text-green-700 border-green-200"
                  : "bg-red-50 text-red-600 border-red-200"
              }`}
            >
              {importStatus}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
