import MovieGrid from "@/components/MovieGrid"

export default function WatchedPage() {
  return (
    <div className="space-y-8">
      <h2 className="text-2xl font-semibold">Watched Movies</h2>
      <MovieGrid type="watched" />
    </div>
  )
}
