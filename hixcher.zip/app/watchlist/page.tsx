import MovieGrid from "@/components/MovieGrid"

export default function WatchlistPage() {
  return (
    <div className="space-y-8">
      <h2 className="text-2xl font-semibold">Your Watchlist</h2>
      <MovieGrid type="watchlist" />
    </div>
  )
}
