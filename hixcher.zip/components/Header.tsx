"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { Film, Home, Eye, BookmarkCheck, Heart, Settings } from "lucide-react"

export default function Header() {
  const pathname = usePathname()

  const navItems = [
    { name: "Home", path: "/", icon: <Home size={18} /> },
    { name: "Watched", path: "/watched", icon: <Eye size={18} /> },
    { name: "Watchlist", path: "/watchlist", icon: <BookmarkCheck size={18} /> },
    { name: "Likes", path: "/likes", icon: <Heart size={18} /> },
    { name: "Settings", path: "/settings", icon: <Settings size={18} /> },
  ]

  return (
    <header className="bg-white border-b border-gray-200 shadow-sm sticky top-0 z-10">
      <div className="container mx-auto px-4 py-3">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between space-y-4 md:space-y-0">
          <Link href="/" className="flex items-center space-x-2">
            <Film className="h-6 w-6 text-[#2383E2]" />
            <span className="text-xl font-bold text-gray-800">Hixcher</span>
          </Link>

          <nav>
            <ul className="flex flex-wrap gap-x-6 gap-y-2">
              {navItems.map((item) => (
                <li key={item.path}>
                  <Link
                    href={item.path}
                    className={`flex items-center space-x-2 transition-colors hover:text-[#2383E2] ${
                      pathname === item.path ? "text-[#2383E2] font-medium" : "text-gray-600"
                    }`}
                  >
                    <span className={pathname === item.path ? "text-[#2383E2]" : "text-gray-500"}>{item.icon}</span>
                    <span>{item.name}</span>
                  </Link>
                </li>
              ))}
            </ul>
          </nav>
        </div>
      </div>
    </header>
  )
}
