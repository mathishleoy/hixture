"use client"

import type React from "react"

import { useState } from "react"
import Image from "next/image"
import { useRouter } from "next/navigation"
import { Eye, Heart, Plus, Check } from "lucide-react"
import type { Movie } from "@/lib/types"
import { useUserData } from "@/lib/hooks"

export default function MovieCard({ movie }: { movie: Movie }) {
  const [isHovered, setIsHovered] = useState(false)
  const router = useRouter()
  const { watched, watchlist, likes, toggleWatched, toggleWatchlist, toggleLike } = useUserData()

  const isWatched = watched.includes(movie.id)
  const isInWatchlist = watchlist.includes(movie.id)
  const isLiked = likes.includes(movie.id)

  const posterUrl = movie.poster_path ? `https://image.tmdb.org/t/p/w500${movie.poster_path}` : "/placeholder.svg"

  const handleCardClick = () => {
    router.push(`/movie/${movie.id}`)
  }

  const handleActionClick = (e: React.MouseEvent, action: () => void) => {
    e.stopPropagation() // Prevent card click when clicking on action buttons
    action()
  }

  return (
    <div
      className="bg-white rounded-lg overflow-hidden shadow-sm border border-gray-200 transition-all duration-300 hover:shadow-md hover:scale-[1.02] cursor-pointer"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      onClick={handleCardClick}
    >
      <div className="relative aspect-[2/3]">
        <Image src={posterUrl || "/placeholder.svg"} alt={movie.title} fill className="object-cover" />

        {/* Overlay with actions */}
        <div
          className={`absolute inset-0 bg-white/90 flex flex-col justify-end p-4 transition-opacity duration-300 ${
            isHovered ? "opacity-100" : "opacity-0"
          }`}
        >
          <div className="flex justify-between mb-4">
            <button
              onClick={(e) => handleActionClick(e, () => toggleWatched(movie.id))}
              className={`p-2 rounded-full transition-colors ${
                isWatched ? "bg-[#EBF4FF] text-[#2383E2]" : "bg-gray-100 text-gray-600 hover:bg-gray-200"
              }`}
              aria-label={isWatched ? "Remove from watched" : "Mark as watched"}
            >
              {isWatched ? <Check size={16} /> : <Eye size={16} />}
            </button>

            <button
              onClick={(e) => handleActionClick(e, () => toggleWatchlist(movie.id))}
              className={`p-2 rounded-full transition-colors ${
                isInWatchlist ? "bg-[#F3E8FF] text-[#9333EA]" : "bg-gray-100 text-gray-600 hover:bg-gray-200"
              }`}
              aria-label={isInWatchlist ? "Remove from watchlist" : "Add to watchlist"}
            >
              {isInWatchlist ? <Check size={16} /> : <Plus size={16} />}
            </button>

            <button
              onClick={(e) => handleActionClick(e, () => toggleLike(movie.id))}
              className={`p-2 rounded-full transition-colors ${
                isLiked ? "bg-[#FEE2E2] text-[#EF4444]" : "bg-gray-100 text-gray-600 hover:bg-gray-200"
              }`}
              aria-label={isLiked ? "Unlike" : "Like"}
            >
              <Heart size={16} className={isLiked ? "fill-current" : ""} />
            </button>
          </div>

          <p className="text-sm text-gray-700 line-clamp-3">{movie.overview || "No description available"}</p>
        </div>
      </div>

      <div className="p-4">
        <h3 className="font-medium text-lg line-clamp-1 text-gray-800">{movie.title}</h3>
        <p className="text-sm text-gray-500">
          {movie.release_date ? new Date(movie.release_date).getFullYear() : "N/A"}
        </p>
      </div>
    </div>
  )
}
