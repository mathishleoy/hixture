"use client"

import { useState, useEffect } from "react"
import { fetchNowPlaying, fetchMovieDetails } from "@/lib/api"
import MovieCard from "./MovieCard"
import type { Movie } from "@/lib/types"
import { useUserData } from "@/lib/hooks"

export default function MovieGrid({ type }: { type: "now-playing" | "watched" | "watchlist" | "likes" }) {
  const [movies, setMovies] = useState<Movie[]>([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const { watched, watchlist, likes } = useUserData()

  useEffect(() => {
    const loadMovies = async () => {
      if (type === "now-playing") {
        setLoading(true)
        setError(null)

        try {
          const data = await fetchNowPlaying()
          setMovies(data)
        } catch (err) {
          console.error("Error in MovieGrid:", err)
          setError("Failed to load movies. Please try again later.")
        } finally {
          setLoading(false)
        }
      } else {
        // For user lists, we need to fetch details for each movie ID
        setLoading(true)
        setError(null)

        try {
          let movieIds: number[] = []

          if (type === "watched") {
            movieIds = watched
          } else if (type === "watchlist") {
            movieIds = watchlist
          } else if (type === "likes") {
            movieIds = likes
          }

          if (movieIds.length === 0) {
            setMovies([])
            setLoading(false)
            return
          }

          // Fetch details for each movie using the function from lib/api.ts
          const moviePromises = movieIds.map((id) =>
            fetchMovieDetails(id).catch((error) => {
              console.error(`Error fetching details for movie ${id}:`, error)
              return null
            }),
          )

          const movieDetails = await Promise.all(moviePromises)
          // Filter out any null results from failed requests
          setMovies(movieDetails.filter((movie) => movie !== null) as Movie[])
        } catch (err) {
          console.error(`Failed to load ${type} movies:`, err)
          setError(`Failed to load ${type} movies. Please try again later.`)
        } finally {
          setLoading(false)
        }
      }
    }

    loadMovies()
  }, [type, watched, watchlist, likes])

  if (loading) {
    return (
      <div className="flex justify-center py-12">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-[#2383E2]"></div>
      </div>
    )
  }

  if (error) {
    return <div className="bg-red-50 text-red-600 p-4 rounded-md border border-red-200">{error}</div>
  }

  if (movies.length === 0) {
    return (
      <div className="text-center py-12 text-gray-500">
        {type === "now-playing" ? "No movies available at the moment" : `No movies in your ${type} list yet`}
      </div>
    )
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6">
      {movies.map((movie) => (
        <MovieCard key={movie.id} movie={movie} />
      ))}
    </div>
  )
}
