"use client"

import { useState, useEffect } from "react"
import { Search } from "lucide-react"
import { fetchSearchResults } from "@/lib/api"
import MovieCard from "./MovieCard"
import type { Movie } from "@/lib/types"

export default function SearchBar() {
  const [query, setQuery] = useState("")
  const [results, setResults] = useState<Movie[]>([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const searchMovies = async () => {
      if (query.trim().length === 0) {
        setResults([])
        return
      }

      setLoading(true)
      setError(null)

      try {
        const data = await fetchSearchResults(query)
        setResults(data)
      } catch (err) {
        setError("Failed to search movies")
        console.error(err)
      } finally {
        setLoading(false)
      }
    }

    // Debounce search requests
    const timeoutId = setTimeout(searchMovies, 500)
    return () => clearTimeout(timeoutId)
  }, [query])

  return (
    <div className="space-y-6">
      <div className="relative">
        <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
          <Search className="h-5 w-5 text-gray-400" />
        </div>
        <input
          type="text"
          className="block w-full pl-10 pr-3 py-2 bg-white border border-gray-200 rounded-md focus:outline-none focus:ring-2 focus:ring-[#2383E2] focus:border-[#2383E2] transition-colors"
          placeholder="Search movies..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
        />
      </div>

      {loading && (
        <div className="flex justify-center py-8">
          <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-[#2383E2]"></div>
        </div>
      )}

      {error && <div className="bg-red-50 text-red-600 p-4 rounded-md border border-red-200">{error}</div>}

      {!loading && !error && results.length > 0 && (
        <div className="space-y-4">
          <h3 className="text-xl font-medium text-gray-800">Search Results</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6">
            {results.map((movie) => (
              <MovieCard key={movie.id} movie={movie} />
            ))}
          </div>
        </div>
      )}

      {!loading && !error && query && results.length === 0 && (
        <div className="text-center py-8 text-gray-500">No movies found matching "{query}"</div>
      )}
    </div>
  )
}
