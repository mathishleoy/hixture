import type { Movie, MovieDetails, Credits } from "./types"

// TMDb API key
const API_KEY = "13c1c0485c7443aa0d44aa7b66682b6e"

export async function fetchNowPlaying(): Promise<Movie[]> {
  try {
    const response = await fetch(
      `https://api.themoviedb.org/3/movie/now_playing?api_key=${API_KEY}&language=en-US&page=1`,
    )

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}))
      console.error("API Error:", response.status, errorData)
      throw new Error(`Failed to fetch now playing movies: ${response.status} ${response.statusText}`)
    }

    const data = await response.json()

    if (!data.results || !Array.isArray(data.results)) {
      console.error("Unexpected API response format:", data)
      throw new Error("Invalid API response format")
    }

    return data.results
  } catch (error) {
    console.error("Error fetching now playing movies:", error)
    throw error
  }
}

export async function fetchSearchResults(query: string): Promise<Movie[]> {
  try {
    const response = await fetch(
      `https://api.themoviedb.org/3/search/movie?api_key=${API_KEY}&language=en-US&query=${encodeURIComponent(query)}&page=1&include_adult=false`,
    )

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}))
      console.error("API Error:", response.status, errorData)
      throw new Error(`Failed to fetch search results: ${response.status} ${response.statusText}`)
    }

    const data = await response.json()

    if (!data.results || !Array.isArray(data.results)) {
      console.error("Unexpected API response format:", data)
      throw new Error("Invalid API response format")
    }

    return data.results
  } catch (error) {
    console.error("Error fetching search results:", error)
    throw error
  }
}

export async function fetchMovieDetails(id: number): Promise<MovieDetails> {
  try {
    const response = await fetch(`https://api.themoviedb.org/3/movie/${id}?api_key=${API_KEY}&language=en-US`)

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}))
      console.error("API Error:", response.status, errorData)
      throw new Error(`Failed to fetch movie details: ${response.status} ${response.statusText}`)
    }

    return response.json()
  } catch (error) {
    console.error(`Error fetching movie details for ID ${id}:`, error)
    throw error
  }
}

export async function fetchMovieCredits(id: number): Promise<Credits> {
  try {
    const response = await fetch(`https://api.themoviedb.org/3/movie/${id}/credits?api_key=${API_KEY}&language=en-US`)

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}))
      console.error("API Error:", response.status, errorData)
      throw new Error(`Failed to fetch movie credits: ${response.status} ${response.statusText}`)
    }

    return response.json()
  } catch (error) {
    console.error(`Error fetching movie credits for ID ${id}:`, error)
    throw error
  }
}
