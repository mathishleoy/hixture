"use client"

import { useState, useEffect } from "react"

export function useUserData() {
  const [watched, setWatched] = useState<number[]>([])
  const [watchlist, setWatchlist] = useState<number[]>([])
  const [likes, setLikes] = useState<number[]>([])

  // Load data from localStorage on initial render
  useEffect(() => {
    const loadedWatched = JSON.parse(localStorage.getItem("hixcher-watched") || "[]")
    const loadedWatchlist = JSON.parse(localStorage.getItem("hixcher-watchlist") || "[]")
    const loadedLikes = JSON.parse(localStorage.getItem("hixcher-likes") || "[]")

    setWatched(loadedWatched)
    setWatchlist(loadedWatchlist)
    setLikes(loadedLikes)
  }, [])

  // Save to localStorage whenever data changes
  useEffect(() => {
    localStorage.setItem("hixcher-watched", JSON.stringify(watched))
  }, [watched])

  useEffect(() => {
    localStorage.setItem("hixcher-watchlist", JSON.stringify(watchlist))
  }, [watchlist])

  useEffect(() => {
    localStorage.setItem("hixcher-likes", JSON.stringify(likes))
  }, [likes])

  const toggleWatched = (movieId: number) => {
    setWatched((prev) => (prev.includes(movieId) ? prev.filter((id) => id !== movieId) : [...prev, movieId]))
  }

  const toggleWatchlist = (movieId: number) => {
    setWatchlist((prev) => (prev.includes(movieId) ? prev.filter((id) => id !== movieId) : [...prev, movieId]))
  }

  const toggleLike = (movieId: number) => {
    setLikes((prev) => (prev.includes(movieId) ? prev.filter((id) => id !== movieId) : [...prev, movieId]))
  }

  return {
    watched,
    watchlist,
    likes,
    toggleWatched,
    toggleWatchlist,
    toggleLike,
  }
}
