export interface Movie {
  id: number
  title: string
  original_title?: string
  overview: string
  poster_path: string | null
  backdrop_path?: string | null
  release_date: string
  vote_average: number
  runtime?: number
  genres?: { id: number; name: string }[]
  production_companies?: { id: number; name: string; logo_path?: string | null }[]
}

export interface MovieDetails extends Movie {
  budget?: number
  revenue?: number
  status?: string
  tagline?: string
  homepage?: string
  imdb_id?: string
  spoken_languages?: { iso_639_1: string; name: string }[]
  production_countries?: { iso_3166_1: string; name: string }[]
  belongs_to_collection?: {
    id: number
    name: string
    poster_path: string | null
    backdrop_path: string | null
  } | null
}

export interface CastMember {
  id: number
  name: string
  character: string
  profile_path: string | null
  order: number
  gender?: number
  credit_id: string
}

export interface CrewMember {
  id: number
  name: string
  department: string
  job: string
  profile_path: string | null
  gender?: number
  credit_id: string
}

export interface Credits {
  id: number
  cast: CastMember[]
  crew: CrewMember[]
}
